gnome-terminal -- ./a.out neighbors1.txt vectors.txt 1 18181 2 &
gnome-terminal -- ./a.out neighbors2.txt vectors.txt 2 18182 3 &
gnome-terminal -- ./a.out neighbors3.txt vectors.txt 3 18183 2 &
gnome-terminal -- ./a.out neighbors4.txt vectors.txt 4 18184 3 &
gnome-terminal -- ./a.out neighbors5.txt vectors.txt 5 18185 2
